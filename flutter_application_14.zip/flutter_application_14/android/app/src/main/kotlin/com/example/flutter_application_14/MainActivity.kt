package com.example.flutter_application_14

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
